[← go back to the main page](../README.md)

# 파이슨 학습
- [nbviewer사이트](https://nbviewer.jupyter.org/)
- Website: [학습진행코드 nbviewer사이트에서 보기](https://nbviewer.jupyter.org/github/mbi4001/m1_1.github.io/blob/main/Jupyter/scraping%20python.ipynb)
